package beanWood.springBoot.wishList.dto;

import lombok.Data;

@Data
public class IWishList {
	private Long id;
	private Long productId;
}
