package beanWood.springBoot.sliderList.repository;

import beanWood.springBoot.sliderList.model.SliderList;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SliderListRepository extends JpaRepository<SliderList, Long> {
}
