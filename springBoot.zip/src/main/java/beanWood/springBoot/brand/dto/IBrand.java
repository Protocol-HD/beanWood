package beanWood.springBoot.brand.dto;

import lombok.Data;

@Data
public class IBrand {
    private Long ImageId;
    private String brandName;
}
