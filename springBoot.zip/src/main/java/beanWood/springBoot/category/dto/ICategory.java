package beanWood.springBoot.category.dto;

import lombok.Data;

@Data
public class ICategory {
    private Long id;
    private Long ImageId;
    private String categoryName;
}
