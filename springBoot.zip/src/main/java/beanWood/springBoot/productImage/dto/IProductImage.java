package beanWood.springBoot.productImage.dto;

import lombok.Data;

@Data
public class IProductImage {
	private Long id;
	private Long imageId;
	private Long productId;
}
