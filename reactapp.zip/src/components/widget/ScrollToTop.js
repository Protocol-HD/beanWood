import React from 'react';

function ScrollToTop() {
    return ( 
        <div id="scroll-to-top" class="scroll-to-top">
            <span class="material-icons-outlined">expand_less</span>
        </div>
    );
}

export default ScrollToTop;