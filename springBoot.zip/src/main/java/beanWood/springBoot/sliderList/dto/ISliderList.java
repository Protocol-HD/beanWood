package beanWood.springBoot.sliderList.dto;

import lombok.Data;

@Data
public class ISliderList {
    private Long id;
    private String eventName;
    private Long imageId;
    private Long productId;
}
