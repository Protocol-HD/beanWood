import React from 'react';

function ContentBottom () {
    return ( 
        <div className="col-12">
        <div className="product-description-content section-top-gap-120">
            <h6 className="title">Description</h6>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of
                type and scrambled it to make a type specimen book. It has survivedLorem Ipsum is simply dummy
                text of the printing and typesetting industry. Lorem Ipsum has been </p>

            <p>the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of
                type and scrambled it to make a type specimen book</p>

            <ul className="items-info-list">
                <li>There are many variations of passages</li>
                <li>If you are going to use a passage of Lorem Ipsum.</li>
                <li>The generated Lorem Ipsum is therefore</li>
                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                <li>At vero eos et accusamus et iusto odio dignissimos</li>
            </ul>

            <p>the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of
                type and scrambled it to make a type specimen book</p>

            <div className="social-links">
                <span className="text">Share:</span>
                <div className="items">
                    <a href="https://example.com/"><img className="icon-svg" src="assets/images/icons/icon-facebook-f-dark.svg" alt="" /></a>
                    <a href="https://example.com/"><img className="icon-svg" src="assets/images/icons/icon-twitter-dark.svg" alt="" /></a>
                    <a href="https://example.com/"><img className="icon-svg" src="assets/images/icons/icon-pinterest-p-dark.svg" alt="" /></a>
                    <a href="https://example.com/"><img className="icon-svg" src="assets/images/icons/icon-dribbble-dark.svg" alt="" /></a>
                </div>
            </div>
        </div>
    </div>
     );
}

export default ContentBottom;